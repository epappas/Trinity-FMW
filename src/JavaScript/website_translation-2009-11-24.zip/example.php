<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>Google Site Tranasalation Script Made By Gourab Singha PHP Programmer</title>
    </head>
  <body >
  <?
  include("tranasalatorhelper.php");
  ?>
<!--------  Here Is The tranasalation Menu  Which display Google Tranasalation Tool As a Drop Down format  ------------------------>
  <?
  echo $language_menu;
  ?>
<!--------  End Of That Section  ------------------------>  
  <div>Hello , This Is Gourab Singha a php programer From INDIA , WestBengal, Kolkata , Village Gobra </div>
  
  <!----------------  Here Is the javascript which help in google tranasalation   ------------------->
  <!--------------   Could not bother with it just copy and paste --------------------------->
   <?
  echo $language_script;
  ?>
	  <!----------------  Here Is the javascript which help in google tranasalation   ------------------->
  </body>
</html>
