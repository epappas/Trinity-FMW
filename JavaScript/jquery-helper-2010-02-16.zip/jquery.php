<?php
function low($str){return strtolower($str);}
function up($str){return strtoupper($str); }
function rep($search,$replace,$subject){return str_replace($search,$replace,$subject);}
function len($str){ return strlen($str);}
function pad($s,$padS,$len,$padType=STR_PAD_BOTH){return str_pad($s,len($s)+$len,$padS,$padType);}
function stripTrailingChars($str,$count){return substr($str,0,len($str)-$count);}

function camelCaseGetParts($str, $count=0)
{
	$parts			= array()		;
	$partIndex	=	1					;
	$len				=	len($str)	;
	
	for($i=0;$i<$len;$i++)
	{
		$char	= $str[$i];
		if ($char===up($char))$partIndex++;
		if($partIndex-1 == $count-1 && $count != 0)
		{
			$parts[$partIndex-1] = substr($str,$i,len($str));
			return $parts;
		}
		$parts[$partIndex-1] .= $char;
	}
	return $parts;
	
}

function seriaizeAssocArray($array, $keyWrap,$betweenOp,$valueWrap,$sep)
{
	$str	= "";
	foreach ( $array as $k=>$v)
	{
	 if ( is_array($v))
    $val = '{'.seriaizeAssocArray($v,$keyWrap,$betweenOp,$valueWrap,$sep).'}';
	 else $val = $v;
		$str.= "{$keyWrap}{$k}{$keyWrap}{$betweenOp}{$valueWrap}{$val}{$valueWrap}{$sep}";
	}
	return stripTrailingChars($str,1);
}

function seriaizeArray($array, $valueWrap,$sep)
{
	$str	= "";
	foreach ( $array as $k=>$v)
		$str.= "{$valueWrap}{$v}{$valueWrap}{$sep}";
	return stripTrailingChars($str,1);
}


class jquery
{
  public $string;
  
  public function __contruct($id = null)
  {
    if ( is_null($id) ) $this->string = '$';
    else $this->string = '$('.$id.')';
    return $this;
  }
  
  public function __invoke ($id = null)
  {
    
    return $this->__contruct($id);
    
  }
  
  public function __call($f,$p)
  {
    if ( count($p) == 1 && is_array($p[0]) )
      $params = '{'.seriaizeAssocArray( $p[0],'',': ','',',') .'}';
    else
      $params = seriaizeArray($p,"'",',');
    $this->string .= ".$f(".$params.')';
    return $this;
  }
  
  public function __toString()
  {
    $str = $this->string.';';
    $this->string = '';
    return $str;
  }

}

?>