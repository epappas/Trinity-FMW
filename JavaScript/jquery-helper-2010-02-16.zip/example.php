<?php

  include 'jquery.php';
  $jQuery = new jQuery();

  #
  ## change the html of an element
  echo $jQuery("'#id_here'")->html('new content');
  # output : $('#id_here').html('new content');

  #
  ## use the ajax
  echo $jQuery()->ajax(array(
    'url'=>"'some_url'",
    'type'=>"'POST'",
    'data'=>array(
      'username'=>"'zzerachiel'"
    );
  ));
  # output : $.ajax({url:'some_url',type:'POST',data:{username:'zzerachiel'});

?>